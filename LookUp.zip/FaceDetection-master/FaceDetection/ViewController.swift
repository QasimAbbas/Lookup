//
//  ViewController.swift
//  FaceDetection
//

import UIKit
import CoreImage
import AVFoundation



protocol VideoFeedDelegate {
    func videoFeed(videoFeed: VideoFeed, didUpdateWithSampleBuffer sampleBuffer: CMSampleBuffer!)
}
var count = 0
var maxHeight :CGFloat = 0
var maxWidth :CGFloat = 0
var text1:String = "Searching..."
var text2:String = ""
var sending = false

class VideoFeed: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    // create a serial dispatch queue used for the sample buffer delegate as well as when a still image is captured
    // a serial dispatch queue must be used to guarantee that video frames will be delivered in order
    // see the header doc for setSampleBufferDelegate:queue: for more information
    let outputQueue = dispatch_queue_create("VideoDataOutputQueue", DISPATCH_QUEUE_SERIAL)
    
    let device: AVCaptureDevice? = {
        let devices = AVCaptureDevice.devicesWithMediaType(AVMediaTypeVideo) as! [AVCaptureDevice]
        var camera: AVCaptureDevice? = nil
        for device in devices {
            if device.position == .Front {
                camera = device
            }
        }
        return camera
    }()
    
    var input: AVCaptureDeviceInput? = nil
    var delegate: VideoFeedDelegate? = nil
    
    let session: AVCaptureSession = {
        let session = AVCaptureSession()
        session.sessionPreset = AVCaptureSessionPresetHigh
        return session
    }()
    
    let videoDataOutput: AVCaptureVideoDataOutput = {
        let output = AVCaptureVideoDataOutput()
        output.videoSettings = [ kCVPixelBufferPixelFormatTypeKey: NSNumber(unsignedInt: kCMPixelFormat_32BGRA) ]
        output.alwaysDiscardsLateVideoFrames = true
        return output
    }()
    
    func start() throws {
        var error: NSError! = NSError(domain: "Migrator", code: 0, userInfo: nil)
        do {
            try configure()
            session.startRunning()
            return
        } catch let error1 as NSError {
            error = error1
        }
        throw error
    }
    
    func stop() {
        session.stopRunning()
    }
    
    private func configure() throws {
        var error: NSError! = NSError(domain: "Migrator", code: 0, userInfo: nil)
        do {
            let maybeInput: AnyObject = try AVCaptureDeviceInput(device: device!)
            input = maybeInput as? AVCaptureDeviceInput
            if session.canAddInput(input) {
                session.addInput(input)
                videoDataOutput.setSampleBufferDelegate(self, queue: outputQueue);
                if session.canAddOutput(videoDataOutput) {
                    session.addOutput(videoDataOutput)
                    let connection = videoDataOutput.connectionWithMediaType(AVMediaTypeVideo)
                    connection.videoOrientation = AVCaptureVideoOrientation.Portrait
                    return
                } else {
                    print("Video output error.");
                }
            } else {
                print("Video input error. Maybe unauthorised or no camera.")
            }
        } catch let error1 as NSError {
            error = error1
            print("Failed to start capturing video with error: \(error)")
        }
        throw error
    }
    
    func captureOutput(captureOutput: AVCaptureOutput!, didOutputSampleBuffer sampleBuffer: CMSampleBuffer!, fromConnection connection: AVCaptureConnection!) {
        // Update the delegate
        if delegate != nil {
            delegate!.videoFeed(self, didUpdateWithSampleBuffer: sampleBuffer)
        }
    }
}

class FaceObscurationFilter {
    let inputImage: CIImage
    var outputImage: CIImage? = nil
    var originX: CGFloat? = nil
    var originY: CGFloat? = nil
    var width: CGFloat? = nil
    var height: CGFloat? = nil
    var radius: CGFloat? = nil
    
    init(inputImage: CIImage) {
        self.inputImage = inputImage
    }
    
    convenience init(sampleBuffer: CMSampleBuffer) {
        // Create a CIImage from the buffer
        let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer)
        let image = CIImage(CVPixelBuffer: imageBuffer!)
        
        self.init(inputImage: image)
    }
    
    func process() {
        // Detect any faces in the image
        let detector = CIDetector(ofType: CIDetectorTypeFace, context:nil, options:nil)
        let features = detector.featuresInImage(inputImage)
        
       // print("Features: \(features)")
        
        // Build a pixellated version of the image using the CIPixellate filter
        let imageSize = inputImage.extent.size
        let pixellationOptions = [kCIInputScaleKey: max(imageSize.width, imageSize.height) / 10]
        let pixellation = CIFilter(name: "CIPixellate", withInputParameters: pixellationOptions)
        let pixellatedImage = pixellation!.outputImage
        
        // Build a masking image for each of the faces
        var maskImage: CIImage? = nil
        for feature in features {
            // Get feature position and radius for circle
            let xCenter = feature.bounds.origin.x + feature.bounds.size.width / 2.0
            let yCenter = feature.bounds.origin.y + feature.bounds.size.height / 2.0
            
            self.originX = feature.bounds.origin.x / 2.0
            self.originY = feature.bounds.origin.y / 2.0
            self.width = feature.bounds.size.width / 2.0
            self.height = feature.bounds.size.height / 2.0
            
            radius = min(feature.bounds.size.width, feature.bounds.size.height) / 1.5
            
            // Input parameters for the circle filter
            var circleOptions: [String: AnyObject] = [:]
            circleOptions["inputRadius0"] = radius! + 10
            circleOptions["inputRadius1"] = radius! + 1
            circleOptions["inputColor0"] = CIColor(red: 1, green: 1, blue: 1, alpha: 0.5)
            circleOptions["inputColor1"] = CIColor(red: 0, green: 0, blue: 0, alpha: 1)
            circleOptions[kCIInputCenterKey] = CIVector(x: xCenter, y: yCenter, z:5)
           // print("\(xCenter) + \(yCenter) + \(radius)")

            
            // Create radial gradient circle at face position with face radius
            let radialGradient = CIFilter(name: "CIRadialGradient", withInputParameters: circleOptions)
            let circleImage = radialGradient!.outputImage
            
            if maskImage != nil {
                // If the mask image is already set, create a composite of both the
                // new circle image and the old so we're creating one image with all
                // of the circles in it.
                let options = [kCIInputImageKey: circleImage!, kCIInputBackgroundImageKey: maskImage!]
                if let composition = CIFilter(name: "CISourceOverCompositing", withInputParameters: options) {
                    maskImage = composition.outputImage
                }
            } else {
                // If it's not set, remember it for composition next time.
                maskImage = circleImage;
            }
        }
        
        // Create a single blended image made up of the pixellated image, the mask image, and the original image.
        // We want sections of the pixellated image to be removed according to the mask image, to reveal
        // the original image in the background.
        // We use the CIBlendWithMask filter for this, and set the background image as the original image,
        // the input image (the one to be masked) as the pixellated image, and the mask image as, well, the mask.
        var blendOptions: [String: AnyObject] = [:]
        blendOptions[kCIInputImageKey] = pixellatedImage
        blendOptions[kCIInputBackgroundImageKey] = inputImage
        blendOptions[kCIInputMaskImageKey] = maskImage
        let blend = CIFilter(name: "CIBlendWithMask", withInputParameters: blendOptions)
        
        // Finally, set the resulting image as the output
        outputImage = blend!.outputImage
    }
}

class ViewController: UIViewController, VideoFeedDelegate {
    @IBOutlet weak var imageView: UIImageView!
    let feed: VideoFeed = VideoFeed()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        feed.delegate = self
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
       
        
        
        maxHeight = self.view.frame.size.height
        maxWidth = self.view.frame.size.width
        startVideoFeed()
        
        
    }
    
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(animated)
        feed.stop()
        
        
    }
    
    override func viewDidLoad() {
       
    }
    
    
    
    func startVideoFeed() {
        do {
            try feed.start()
            print("Video started.")
           
        }
        catch {
            // alert?
            // need to look into device permissions
        }
    }
    
    func videoFeed(videoFeed: VideoFeed, didUpdateWithSampleBuffer sampleBuffer: CMSampleBuffer!) {
        let filter = FaceObscurationFilter(sampleBuffer: sampleBuffer)
        filter.process()
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            
            
            self.imageView.image = UIImage(CIImage: filter.outputImage!)
            
            //let imageData = UIImage(CIImage: filter.outputImage!)
            
            
//            var imageViewObject :UIImageView
//            imageViewObject = UIImageView(frame:CGRectMake(0, 0, 100, 100));
//            imageViewObject.image = self.imageView.image
//            self.view.addSubview(imageViewObject)
            
          
            
           
            
            if let x = filter.originX, y = filter.originY, _ = filter.width, _ = filter.height, _ = filter.radius{
                if(count == 0){
                    count+=1
                    
                   

                    let image1 = filter.outputImage!
                    let context = CIContext(options: nil)
                    let image2 = context.createCGImage(image1, fromRect: image1.extent)
                    let image3 = UIImage(CGImage: image2)
                    let binary = UIImageJPEGRepresentation(image3, 1)
                    
                 
                    
                    if(!sending){
                        sending = true
                        self.postDataToURL(binary!)
                    }
                  
    
                }else{
                    count--
                     self.view.subviews.forEach({ $0.removeFromSuperview() })
                    
                    
                    
                    let label1 = UILabel(frame: CGRectMake(x*0.8 - 0.10*maxWidth , (maxHeight - y)*0.8 + maxHeight * 0.25, 200, 20))
                    //print("\(x) + \(y) + \(r)")
                    
                    label1.textAlignment = NSTextAlignment.Center
                    label1.text = text1
                    label1.textColor = UIColor.whiteColor()
                    self.view.addSubview(label1)
                    
                    let label2 = UILabel(frame: CGRectMake(x*0.8 - 0.10*maxWidth , (maxHeight - y)*0.8 + maxHeight * 0.25 + 25, 200, 20))
                    //print("\(x) + \(y) + \(r)")
                    
                    label2.textAlignment = NSTextAlignment.Center
                    label2.text = text2
                    label2.textColor = UIColor.whiteColor()
                    self.view.addSubview(label2)

                }
                
                
                
                
                
            }
        })
    }
    
    func postDataToURL(binary: NSData) {
        
        // Setup the session to make REST POST call
        let postEndpoint: String = "http://10.101.192.67:3000/getPerson"
        let url = NSURL(string: postEndpoint)!
        let session = NSURLSession.sharedSession()
        
        let base64String = binary.base64EncodedStringWithOptions([])
        let postParams : [NSString: AnyObject] = ["img": base64String]
        
        // Create the request
        let request = NSMutableURLRequest(URL: url)
        request.HTTPMethod = "POST"
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(postParams, options: NSJSONWritingOptions())
         //   print(postParams)
        } catch {
            print("bad things happened")
        }
        
        // Make the POST call and handle it in a completion handler
        session.dataTaskWithRequest(request, completionHandler: { ( data: NSData?, response: NSURLResponse?, error: NSError?) -> Void in
            // Make sure we get an OK response
            guard let realResponse = response as? NSHTTPURLResponse where
                realResponse.statusCode == 200 else {
                    print("Not a 200 response")
                    return
            }
            
            
          //   Read the JSON
            if let postString = NSString(data:data!, encoding: NSUTF8StringEncoding) as? String {
          //       Print what we got from the call
                
                print("POST: " + postString)
                
                do{
                    
                    let json = try NSJSONSerialization.JSONObjectWithData(data!, options:.AllowFragments)
                    
                    if let names = json["name"] as? String {
                        
                        text1 = names
                    }
                    
                    if let likes = json["Likes"] as? String {
                        
                        text2 = likes
                    }
                    
                }catch {
                    print("Error with Json: \(error)")
                }            }
            
            sending = false
            
        }).resume()
    }
    
}
